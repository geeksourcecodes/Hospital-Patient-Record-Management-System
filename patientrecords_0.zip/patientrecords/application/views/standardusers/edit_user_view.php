
 

          <!-- DataTales Example -->
          <div  id="editusertable" class="card shadow mb-4">
      
            <div class="card-header py-3">
           
            <!-- Page Heading -->
          <h5 class="mb-2 text-gray-800">Edit User <?php echo "<a style='margin-left: 800px; text-decoration:none;' class='text-secondary' href='". base_url() ."addusercontrol/adduserview/#addusertable'>" ?> <i class="fa 
                   fa-arrow-left"></i></a> </h5>  

            </div>
            <div class="card-body">
       <div class="container">
             </div>
           
           
               
                <td class='text-center'><?php $this->load->view($editform); ?></td>
          

               
            </div>
          </div>



 