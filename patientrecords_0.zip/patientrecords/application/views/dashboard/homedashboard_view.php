



  <div class="align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800 text-center">Dashboard</h1>
          </div>

  <div class="row"> <!-- Begin of Row -->

      <div class="col-xl-4 col-md-4 mb-4">
              <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col-auto">
             <div class="text-xs font-weight-bold text-success text-uppercase mb-1">TOTAL  NUMBER  OF  PATIENT  RECORDS</div>
             </div>
                    <div class="col mr-2">
                      <div class="h3 mb-0 font-weight-bold text-gray-800">
                    
                      <?php echo "&nbsp&nbsp&nbsp&nbsp&nbsp <a class='text-secondary' href='". base_url()."admissioncontrol/admitdatatable'>".$get_all_patient."</a>" ?>
                         
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

             
             <div class="col-xl-4 col-md-4 mb-4 ml-auto">
              <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col-auto">
               <div class="text-xs font-weight-bold text-success text-uppercase mb-1">NUMBER OF USER ACCOUNTS</div>
             </div>
                       <div class="col mr-2">
                      <div class="h3 mb-0 font-weight-bold text-gray-800">
                        
                       <?php echo "&nbsp&nbsp&nbsp&nbsp&nbsp <a class='text-secondary' href='". base_url()."addusercontrol/adduserview'>".$get_all_user."</a>" ?>
                        

                      </div>
                    </div>   
                  </div>
                </div>
              </div>
            </div>



              <div class="col-xl-4 col-md-4 mb-4 ml-auto">
              <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col-auto">
               <div class="text-xs font-weight-bold text-success text-uppercase mb-1">NUMBER OF DOCTORS REGISTERED</div>
             </div>
                       <div class="col mr-2">
                      <div class="h3 mb-0 font-weight-bold text-gray-800">
                        
                       <?php echo "&nbsp&nbsp&nbsp&nbsp&nbsp <a class='text-secondary' href='". base_url()."addusercontrol/adddoctorview'>".$get_all_doctor."</a>" ?>
                        
                      </div>
                    </div>   
                  </div>
                </div>
              </div>
            </div>


    </div><!-- End of Row -->




          <!-- DataTales Example -->
          <div  class="card shadow mb-4">
      
            <div class="card-header py-3">
           
            <!-- Page Heading -->
          <h5 class="mb-2 text-gray-800 text-success"> Monthly Patient Population
                  </h5>  

            </div>
            <div class="card-body">





              
            </div>
          </div>

