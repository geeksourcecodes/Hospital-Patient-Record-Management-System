<h2 class="text-center">Welcome to Patient Record Management System</h2>


    <div class="loader-wrapper">
      <span class="loader"><span class="loader-inner"></span></span>
    </div>


   <script>
    $(window).on('load',function(){
     $(".loader-wrapper").fadeOut("slow");
    });
 </script>
